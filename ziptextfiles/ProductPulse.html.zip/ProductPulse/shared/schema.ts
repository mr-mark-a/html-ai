import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: real("price").notNull(),
  imageUrl: text("image_url"),
  category: text("category").notNull(),
  brand: text("brand"),
  externalId: text("external_id"), // For linking to external product APIs
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const productAnalyses = pgTable("product_analyses", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  overallRating: real("overall_rating").notNull(),
  pros: jsonb("pros").$type<string[]>().notNull(),
  cons: jsonb("cons").$type<string[]>().notNull(),
  summary: text("summary").notNull(),
  scores: jsonb("scores").$type<{
    design: number;
    performance: number;
    camera: number;
    value: number;
  }>().notNull(),
  reviewCount: integer("review_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

export const insertProductAnalysisSchema = createInsertSchema(productAnalyses).omit({
  id: true,
  createdAt: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type InsertProductAnalysis = z.infer<typeof insertProductAnalysisSchema>;
export type ProductAnalysis = typeof productAnalyses.$inferSelect;

export type ProductWithAnalysis = Product & {
  analysis?: ProductAnalysis;
};

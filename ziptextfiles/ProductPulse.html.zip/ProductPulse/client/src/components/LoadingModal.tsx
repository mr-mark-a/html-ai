import { Loader2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface LoadingModalProps {
  isOpen: boolean;
  title?: string;
  description?: string;
}

export default function LoadingModal({ 
  isOpen, 
  title = "Analyzing Product...", 
  description = "Our AI is processing reviews and generating insights" 
}: LoadingModalProps) {
  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md">
        <div className="text-center p-6">
          <div className="mb-4">
            <Loader2 className="h-12 w-12 text-primary mx-auto animate-spin" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4">{description}</p>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: "60%" }} />
          </div>
          <p className="text-sm text-gray-500 mt-2">This usually takes 30-60 seconds</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { Link } from "wouter";
import { Star, StarHalf, ThumbsUp, ThumbsDown, Clock, Plus, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import PaymentModal from "@/components/PaymentModal";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithAnalysis } from "@shared/schema";

interface ProductCardProps {
  product: ProductWithAnalysis;
  showActions?: boolean;
}

export default function ProductCard({ product, showActions = true }: ProductCardProps) {
  const { analysis } = product;
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [savedProducts, setSavedProducts] = useState<number[]>([]);
  const [comparisonProducts, setComparisonProducts] = useState<number[]>([]);
  const { toast } = useToast();

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-4 w-4 text-gray-300" />);
    }

    return stars;
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'electronics':
        return 'bg-blue-50 text-blue-500';
      case 'audio':
        return 'bg-purple-50 text-purple-500';
      case 'footwear':
        return 'bg-orange-50 text-orange-500';
      default:
        return 'bg-gray-50 text-gray-500';
    }
  };

  const handleAddToComparison = () => {
    if (comparisonProducts.includes(product.id)) {
      setComparisonProducts(prev => prev.filter(id => id !== product.id));
      toast({
        title: "Removed from comparison",
        description: `${product.name} was removed from comparison list`,
      });
    } else {
      setComparisonProducts(prev => [...prev, product.id]);
      toast({
        title: "Added to comparison",
        description: `${product.name} was added to comparison list`,
      });
    }
  };

  const handleSaveProduct = () => {
    if (savedProducts.includes(product.id)) {
      setSavedProducts(prev => prev.filter(id => id !== product.id));
      toast({
        title: "Removed from saved",
        description: `${product.name} was removed from saved products`,
      });
    } else {
      setSavedProducts(prev => [...prev, product.id]);
      toast({
        title: "Product saved",
        description: `${product.name} was saved to your favorites`,
      });
    }
  };

  const handleViewAnalysis = () => {
    if (!analysis) {
      setShowPaymentModal(true);
    }
  };

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment successful!",
      description: "Your product analysis will be ready shortly",
    });
  };

  const handleSkipPayment = () => {
    toast({
      title: "Analysis unlocked",
      description: "Development mode - analysis accessed without payment",
    });
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow card-hover">
      <div className="aspect-video overflow-hidden">
        <img
          src={product.imageUrl || "/api/placeholder/400/300"}
          alt={product.name}
          className="w-full h-full object-cover"
        />
      </div>

      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <Badge className={`text-sm font-medium px-2 py-1 rounded-full ${getCategoryColor(product.category)}`}>
            {product.category}
          </Badge>
          {analysis && (
            <div className="flex items-center">
              <div className="flex mr-1">
                {renderStars(analysis.overallRating)}
              </div>
              <span className="text-sm text-gray-600">{analysis.overallRating.toFixed(1)}</span>
            </div>
          )}
        </div>

        <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4">${product.price.toFixed(2)}</p>

        {analysis && (
          <div className="flex items-center justify-between text-sm mb-4">
            <span className="text-emerald-500 flex items-center">
              <ThumbsUp className="mr-1 h-4 w-4" />
              {analysis.pros.length} Pros
            </span>
            <span className="text-red-500 flex items-center">
              <ThumbsDown className="mr-1 h-4 w-4" />
              {analysis.cons.length} Cons
            </span>
            <span className="text-gray-500 flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              {Math.floor(Math.random() * 60) + 1} min ago
            </span>
          </div>
        )}

        {showActions && (
          <div className="flex gap-2">
            {analysis ? (
              <Button asChild className="flex-1 bg-primary text-white hover:bg-primary/90">
                <Link href={`/product/${product.id}`}>
                  View Full Analysis
                </Link>
              </Button>
            ) : (
              <Button 
                onClick={handleViewAnalysis}
                className="flex-1 bg-primary text-white hover:bg-primary/90"
              >
                Get AI Analysis
              </Button>
            )}
            <Button 
              variant="outline" 
              size="icon" 
              className={`shrink-0 ${comparisonProducts.includes(product.id) ? 'bg-blue-100 border-blue-300' : ''}`}
              onClick={handleAddToComparison}
            >
              <Plus className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className={`shrink-0 ${savedProducts.includes(product.id) ? 'bg-red-100 border-red-300' : ''}`}
              onClick={handleSaveProduct}
            >
              <Heart className={`h-4 w-4 ${savedProducts.includes(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
          </div>
        )}
      </CardContent>

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPaymentSuccess={handlePaymentSuccess}
        onSkipPayment={handleSkipPayment}
        productName={product.name}
      />
    </Card>
  );
}

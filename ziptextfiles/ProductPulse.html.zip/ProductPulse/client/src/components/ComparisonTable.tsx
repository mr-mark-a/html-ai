import { Star, StarHalf } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithAnalysis } from "@shared/schema";

interface ComparisonTableProps {
  products: ProductWithAnalysis[];
  onAddProduct?: () => void;
}

export default function ComparisonTable({ products, onAddProduct }: ComparisonTableProps) {
  const { toast } = useToast();
  
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="h-3 w-3 fill-yellow-400 text-yellow-400" />);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-3 w-3 text-gray-300" />);
    }

    return stars;
  };

  const getScoreBadge = (score: number) => {
    if (score >= 8) return 'bg-green-100 text-green-800';
    if (score >= 6) return 'bg-blue-100 text-blue-800';
    if (score >= 4) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const handleAddProduct = () => {
    if (onAddProduct) {
      onAddProduct();
    } else {
      toast({
        title: "Add products to compare",
        description: "Search for products and click the + button to add them to comparison",
      });
    }
  };

  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500 mb-4">No products selected for comparison</p>
          <Button onClick={handleAddProduct} className="bg-primary text-white">
            Add Products to Compare
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-900">Product</th>
              {products.map(product => (
                <th key={product.id} className="px-6 py-4 text-center text-sm font-medium text-gray-900">
                  {product.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            <tr>
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Overall Rating</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center">
                  {product.analysis ? (
                    <div className="flex items-center justify-center">
                      <div className="flex mr-1">
                        {renderStars(product.analysis.overallRating)}
                      </div>
                      <span className="text-sm">{product.analysis.overallRating.toFixed(1)}</span>
                    </div>
                  ) : (
                    <span className="text-gray-400">N/A</span>
                  )}
                </td>
              ))}
            </tr>

            <tr className="bg-gray-50">
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Price</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center text-sm text-gray-900">
                  ${product.price.toFixed(2)}
                </td>
              ))}
            </tr>

            <tr>
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Design Score</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center">
                  {product.analysis ? (
                    <Badge className={`text-xs px-2 py-1 rounded-full ${getScoreBadge(product.analysis.scores.design)}`}>
                      {product.analysis.scores.design.toFixed(1)}
                    </Badge>
                  ) : (
                    <span className="text-gray-400">N/A</span>
                  )}
                </td>
              ))}
            </tr>

            <tr className="bg-gray-50">
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Performance Score</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center">
                  {product.analysis ? (
                    <Badge className={`text-xs px-2 py-1 rounded-full ${getScoreBadge(product.analysis.scores.performance)}`}>
                      {product.analysis.scores.performance.toFixed(1)}
                    </Badge>
                  ) : (
                    <span className="text-gray-400">N/A</span>
                  )}
                </td>
              ))}
            </tr>

            <tr>
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Feature Score</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center">
                  {product.analysis ? (
                    <Badge className={`text-xs px-2 py-1 rounded-full ${getScoreBadge(product.analysis.scores.camera)}`}>
                      {product.analysis.scores.camera.toFixed(1)}
                    </Badge>
                  ) : (
                    <span className="text-gray-400">N/A</span>
                  )}
                </td>
              ))}
            </tr>

            <tr className="bg-gray-50">
              <td className="px-6 py-4 text-sm font-medium text-gray-900">Value Score</td>
              {products.map(product => (
                <td key={product.id} className="px-6 py-4 text-center">
                  {product.analysis ? (
                    <Badge className={`text-xs px-2 py-1 rounded-full ${getScoreBadge(product.analysis.scores.value)}`}>
                      {product.analysis.scores.value.toFixed(1)}
                    </Badge>
                  ) : (
                    <span className="text-gray-400">N/A</span>
                  )}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
        <div className="flex justify-center">
          <Button onClick={handleAddProduct} className="bg-primary text-white hover:bg-primary/90">
            Add Another Product
          </Button>
        </div>
      </div>
    </Card>
  );
}

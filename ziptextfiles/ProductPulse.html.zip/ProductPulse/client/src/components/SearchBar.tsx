import { useState } from "react";
import { useLocation } from "wouter";
import { Search, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface SearchBarProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
  showSuggestions?: boolean;
}

export default function SearchBar({ onSearch, placeholder = "Search for any product...", showSuggestions = true }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleSearch = () => {
    if (query.trim()) {
      if (onSearch) {
        onSearch(query);
      } else {
        setLocation(`/search?q=${encodeURIComponent(query)}`);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion);
    if (onSearch) {
      onSearch(suggestion);
    } else {
      setLocation(`/search?q=${encodeURIComponent(suggestion)}`);
    }
  };

  const handleScan = () => {
    toast({
      title: "Scan feature coming soon!",
      description: "Camera-based product scanning will be available in the next update",
    });
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <Input
            type="text"
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div className="flex gap-2">
          <Button onClick={handleSearch} className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
            <Search className="mr-2 h-4 w-4" />
            Search
          </Button>
          <Button 
            variant="outline" 
            className="bg-emerald-500 text-white px-6 py-3 rounded-lg hover:bg-emerald-600 transition-colors border-emerald-500"
            onClick={handleScan}
          >
            <Camera className="mr-2 h-4 w-4" />
            Scan
          </Button>
        </div>
      </div>
      
      {showSuggestions && (
        <div className="flex flex-wrap gap-2 mt-4">
          <span className="text-sm text-gray-600">Popular searches:</span>
          <button
            onClick={() => handleSuggestionClick("iPhone 15")}
            className="text-sm text-primary hover:text-primary/80 bg-blue-50 px-3 py-1 rounded-full"
          >
            iPhone 15
          </button>
          <button
            onClick={() => handleSuggestionClick("Sony WH-1000XM4")}
            className="text-sm text-primary hover:text-primary/80 bg-blue-50 px-3 py-1 rounded-full"
          >
            Sony WH-1000XM4
          </button>
          <button
            onClick={() => handleSuggestionClick("Nike Air Max")}
            className="text-sm text-primary hover:text-primary/80 bg-blue-50 px-3 py-1 rounded-full"
          >
            Nike Air Max
          </button>
        </div>
      )}
    </div>
  );
}

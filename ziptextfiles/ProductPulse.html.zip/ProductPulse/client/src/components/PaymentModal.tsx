import { useState } from "react";
import { CreditCard, Check, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: () => void;
  onSkipPayment: () => void;
  productName: string;
}

export default function PaymentModal({ 
  isOpen, 
  onClose, 
  onPaymentSuccess, 
  onSkipPayment,
  productName 
}: PaymentModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'premium'>('basic');
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [nameOnCard, setNameOnCard] = useState('');

  const plans = {
    basic: {
      name: 'Basic Analysis',
      price: 2.99,
      features: [
        'AI-powered product analysis',
        'Pros and cons breakdown',
        'Overall rating score',
        'Basic comparison features'
      ]
    },
    premium: {
      name: 'Premium Analysis',
      price: 5.99,
      features: [
        'Everything in Basic',
        'Detailed score breakdown',
        'Advanced comparison tools',
        'Price tracking alerts',
        'Export analysis reports',
        'Priority support'
      ]
    }
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess();
      onClose();
    }, 2000);
  };

  const handleSkip = () => {
    onSkipPayment();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">
            Get AI Analysis for "{productName}"
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pricing Plans */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Choose Your Plan</h3>
            
            {Object.entries(plans).map(([key, plan]) => (
              <Card 
                key={key}
                className={`cursor-pointer transition-all ${
                  selectedPlan === key 
                    ? 'ring-2 ring-primary border-primary' 
                    : 'hover:border-gray-300'
                }`}
                onClick={() => setSelectedPlan(key as 'basic' | 'premium')}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">
                        ${plan.price}
                      </div>
                      <div className="text-sm text-gray-500">one-time</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <Check className="h-4 w-4 text-green-500 mr-2 shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}

            {/* Temporary Skip Button */}
            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-yellow-800">
                    Development Mode
                  </p>
                  <p className="text-xs text-yellow-600">
                    Skip payment for testing purposes
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleSkip}
                  className="border-yellow-300 text-yellow-700 hover:bg-yellow-100"
                >
                  Skip Payment
                </Button>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Payment Details</h3>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">
                  {plans[selectedPlan].name}
                </span>
                <span className="text-xl font-bold text-primary">
                  ${plans[selectedPlan].price}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                One-time payment for "{productName}" analysis
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  maxLength={19}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    maxLength={5}
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    maxLength={4}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="nameOnCard">Name on Card</Label>
                <Input
                  id="nameOnCard"
                  placeholder="John Doe"
                  value={nameOnCard}
                  onChange={(e) => setNameOnCard(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Button 
                onClick={handlePayment}
                disabled={isProcessing}
                className="w-full bg-primary text-white hover:bg-primary/90"
              >
                {isProcessing ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Processing...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Pay ${plans[selectedPlan].price}
                  </div>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={onClose}
                className="w-full"
                disabled={isProcessing}
              >
                Cancel
              </Button>
            </div>

            <div className="text-xs text-gray-500 text-center">
              <p>🔒 Your payment information is secure and encrypted</p>
              <p>30-day money-back guarantee</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
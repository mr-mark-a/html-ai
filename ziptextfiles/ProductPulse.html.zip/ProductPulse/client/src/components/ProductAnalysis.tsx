import { ThumbsUp, ThumbsDown, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { ProductAnalysis } from "@shared/schema";

interface ProductAnalysisProps {
  analysis: ProductAnalysis;
}

export default function ProductAnalysis({ analysis }: ProductAnalysisProps) {
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-green-500';
    if (score >= 6) return 'bg-blue-500';
    if (score >= 4) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreWidth = (score: number) => `${(score / 10) * 100}%`;

  return (
    <div className="space-y-6">
      {/* AI Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm mr-2">
              AI
            </div>
            AI Analysis Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-800">{analysis.summary}</p>
          </div>
        </CardContent>
      </Card>

      {/* Pros and Cons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pros */}
        <Card className="bg-emerald-50 border-emerald-200">
          <CardHeader>
            <CardTitle className="text-emerald-800 flex items-center">
              <ThumbsUp className="mr-2 h-5 w-5" />
              Pros ({analysis.pros.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {analysis.pros.slice(0, 5).map((pro, index) => (
                <li key={index} className="flex items-start text-emerald-700">
                  <CheckCircle className="mr-2 h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                  <span>{pro}</span>
                </li>
              ))}
            </ul>
            {analysis.pros.length > 5 && (
              <button className="text-emerald-600 hover:text-emerald-800 text-sm mt-3">
                Show all {analysis.pros.length} pros
              </button>
            )}
          </CardContent>
        </Card>

        {/* Cons */}
        <Card className="bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center">
              <ThumbsDown className="mr-2 h-5 w-5" />
              Cons ({analysis.cons.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {analysis.cons.map((con, index) => (
                <li key={index} className="flex items-start text-red-700">
                  <XCircle className="mr-2 h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                  <span>{con}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Score Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Score Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Design & Build</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div
                    className={`h-2 rounded-full ${getScoreColor(analysis.scores.design)}`}
                    style={{ width: getScoreWidth(analysis.scores.design) }}
                  />
                </div>
                <span className="text-sm font-medium">{analysis.scores.design.toFixed(1)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Performance</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div
                    className={`h-2 rounded-full ${getScoreColor(analysis.scores.performance)}`}
                    style={{ width: getScoreWidth(analysis.scores.performance) }}
                  />
                </div>
                <span className="text-sm font-medium">{analysis.scores.performance.toFixed(1)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Features</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div
                    className={`h-2 rounded-full ${getScoreColor(analysis.scores.camera)}`}
                    style={{ width: getScoreWidth(analysis.scores.camera) }}
                  />
                </div>
                <span className="text-sm font-medium">{analysis.scores.camera.toFixed(1)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Value for Money</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div
                    className={`h-2 rounded-full ${getScoreColor(analysis.scores.value)}`}
                    style={{ width: getScoreWidth(analysis.scores.value) }}
                  />
                </div>
                <span className="text-sm font-medium">{analysis.scores.value.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

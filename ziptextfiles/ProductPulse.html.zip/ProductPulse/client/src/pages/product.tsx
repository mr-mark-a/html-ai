import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Star, StarHalf, Plus, Heart, Share2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductAnalysis from "@/components/ProductAnalysis";
import PaymentModal from "@/components/PaymentModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithAnalysis } from "@shared/schema";

export default function Product() {
  const [, params] = useRoute("/product/:id");
  const { toast } = useToast();
  const productId = params?.id ? parseInt(params.id) : null;
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [savedProducts, setSavedProducts] = useState<number[]>([]);
  const [comparisonProducts, setComparisonProducts] = useState<number[]>([]);

  const { data: product, isLoading, error } = useQuery<ProductWithAnalysis>({
    queryKey: ["/api/products", productId],
    enabled: !!productId,
  });

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="h-5 w-5 fill-yellow-400 text-yellow-400" />);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-5 w-5 text-gray-300" />);
    }

    return stars;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product?.name,
        text: `Check out this product analysis for ${product?.name}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Product link has been copied to clipboard",
      });
    }
  };

  const handleAddToComparison = () => {
    if (!product) return;
    
    if (comparisonProducts.includes(product.id)) {
      setComparisonProducts(prev => prev.filter(id => id !== product.id));
      toast({
        title: "Removed from comparison",
        description: `${product.name} was removed from comparison list`,
      });
    } else {
      setComparisonProducts(prev => [...prev, product.id]);
      toast({
        title: "Added to comparison",
        description: `${product.name} was added to comparison list`,
      });
    }
  };

  const handleSaveProduct = () => {
    if (!product) return;
    
    if (savedProducts.includes(product.id)) {
      setSavedProducts(prev => prev.filter(id => id !== product.id));
      toast({
        title: "Removed from saved",
        description: `${product.name} was removed from saved products`,
      });
    } else {
      setSavedProducts(prev => [...prev, product.id]);
      toast({
        title: "Product saved",
        description: `${product.name} was saved to your favorites`,
      });
    }
  };

  const handleRequestAnalysis = () => {
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment successful!",
      description: "Your product analysis will be ready shortly",
    });
    // In a real app, this would trigger a refetch of the product data
  };

  const handleSkipPayment = () => {
    toast({
      title: "Analysis unlocked",
      description: "Development mode - analysis accessed without payment",
    });
    // In a real app, this would trigger the analysis generation
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <Skeleton className="h-8 w-32 mb-6" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <Skeleton className="w-full h-96 rounded-lg" />
              </div>
              <div>
                <Skeleton className="h-8 w-full mb-4" />
                <Skeleton className="h-6 w-3/4 mb-4" />
                <Skeleton className="h-6 w-24 mb-4" />
                <Skeleton className="h-10 w-full mb-4" />
                <div className="flex gap-2">
                  <Skeleton className="h-10 flex-1" />
                  <Skeleton className="h-10 w-16" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-8">The product you're looking for doesn't exist or has been removed.</p>
            <Button asChild className="bg-primary text-white">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Breadcrumb */}
          <nav className="mb-6">
            <Button variant="ghost" asChild>
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </nav>

          {/* Product Details */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Product Image */}
                <div>
                  <img
                    src={product.imageUrl || "/api/placeholder/600/600"}
                    alt={product.name}
                    className="w-full rounded-lg shadow-lg"
                  />
                </div>

                {/* Product Info */}
                <div>
                  <Badge className="mb-4">{product.category}</Badge>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                  <p className="text-gray-600 mb-4">{product.description}</p>

                  {product.analysis && (
                    <div className="flex items-center mb-4">
                      <div className="flex mr-2">
                        {renderStars(product.analysis.overallRating)}
                      </div>
                      <span className="text-xl font-bold text-gray-900">
                        {product.analysis.overallRating.toFixed(1)}
                      </span>
                      <span className="text-gray-600 ml-2">
                        ({product.analysis.reviewCount} reviews)
                      </span>
                    </div>
                  )}

                  <div className="text-3xl font-bold text-primary mb-6">
                    ${product.price.toFixed(2)}
                  </div>

                  <div className="flex gap-4 mb-6">
                    <Button 
                      className={`flex-1 ${comparisonProducts.includes(product.id) ? 'bg-blue-600' : 'bg-primary'} text-white hover:bg-primary/90`}
                      onClick={handleAddToComparison}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      {comparisonProducts.includes(product.id) ? 'Remove from Compare' : 'Add to Compare'}
                    </Button>
                    <Button 
                      variant="outline" 
                      className={`flex-1 ${savedProducts.includes(product.id) ? 'bg-red-50 border-red-300' : ''}`}
                      onClick={handleSaveProduct}
                    >
                      <Heart className={`mr-2 h-4 w-4 ${savedProducts.includes(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                      {savedProducts.includes(product.id) ? 'Remove from Saved' : 'Save Product'}
                    </Button>
                    <Button variant="outline" size="icon" onClick={handleShare}>
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>

                  {product.brand && (
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Brand:</span> {product.brand}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Product Analysis */}
          {product.analysis ? (
            <ProductAnalysis analysis={product.analysis} />
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-600 mb-4">No analysis available for this product yet.</p>
                <Button 
                  className="bg-primary text-white"
                  onClick={handleRequestAnalysis}
                >
                  Request Analysis
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Footer />
      
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPaymentSuccess={handlePaymentSuccess}
        onSkipPayment={handleSkipPayment}
        productName={product?.name || "Product"}
      />
    </div>
  );
}

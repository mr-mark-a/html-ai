import { products, productAnalyses, type Product, type InsertProduct, type ProductAnalysis, type InsertProductAnalysis, type ProductWithAnalysis } from "@shared/schema";

export interface IStorage {
  // Product methods
  getProduct(id: number): Promise<Product | undefined>;
  getProductByName(name: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  searchProducts(query: string): Promise<Product[]>;
  getAllProducts(): Promise<Product[]>;
  
  // Analysis methods
  getProductAnalysis(productId: number): Promise<ProductAnalysis | undefined>;
  createProductAnalysis(analysis: InsertProductAnalysis): Promise<ProductAnalysis>;
  getProductWithAnalysis(productId: number): Promise<ProductWithAnalysis | undefined>;
  getProductsWithAnalysis(): Promise<ProductWithAnalysis[]>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private productAnalyses: Map<number, ProductAnalysis>;
  private currentProductId: number;
  private currentAnalysisId: number;

  constructor() {
    this.products = new Map();
    this.productAnalyses = new Map();
    this.currentProductId = 1;
    this.currentAnalysisId = 1;
    
    // Initialize with some sample products
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample products matching the design
    const sampleProducts = [
      {
        name: "iPhone 15 Pro",
        description: "Apple's latest flagship smartphone",
        price: 999.00,
        imageUrl: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "Electronics",
        brand: "Apple",
        externalId: "apple-iphone-15-pro"
      },
      {
        name: "Sony WH-1000XM4",
        description: "Premium noise-canceling headphones",
        price: 349.99,
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "Audio",
        brand: "Sony",
        externalId: "sony-wh-1000xm4"
      },
      {
        name: "Nike Air Max 270",
        description: "Comfortable running sneakers",
        price: 150.00,
        imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "Footwear",
        brand: "Nike",
        externalId: "nike-air-max-270"
      }
    ];

    // Add sample products
    sampleProducts.forEach(product => {
      const id = this.currentProductId++;
      const newProduct: Product = { ...product, id, createdAt: new Date() };
      this.products.set(id, newProduct);
    });
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByName(name: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.name.toLowerCase().includes(name.toLowerCase())
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id, 
      createdAt: new Date(),
      description: insertProduct.description || null,
      brand: insertProduct.brand || null,
      imageUrl: insertProduct.imageUrl || null,
      externalId: insertProduct.externalId || null
    };
    this.products.set(id, product);
    return product;
  }

  async searchProducts(query: string): Promise<Product[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description?.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm) ||
        product.brand?.toLowerCase().includes(searchTerm)
    );
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductAnalysis(productId: number): Promise<ProductAnalysis | undefined> {
    return Array.from(this.productAnalyses.values()).find(
      (analysis) => analysis.productId === productId
    );
  }

  async createProductAnalysis(insertAnalysis: InsertProductAnalysis): Promise<ProductAnalysis> {
    const id = this.currentAnalysisId++;
    const analysis: ProductAnalysis = { 
      ...insertAnalysis, 
      id, 
      createdAt: new Date(),
      pros: insertAnalysis.pros as string[],
      cons: insertAnalysis.cons as string[],
      reviewCount: insertAnalysis.reviewCount || 0
    };
    this.productAnalyses.set(id, analysis);
    return analysis;
  }

  async getProductWithAnalysis(productId: number): Promise<ProductWithAnalysis | undefined> {
    const product = await this.getProduct(productId);
    if (!product) return undefined;

    const analysis = await this.getProductAnalysis(productId);
    return { ...product, analysis };
  }

  async getProductsWithAnalysis(): Promise<ProductWithAnalysis[]> {
    const products = await this.getAllProducts();
    const productsWithAnalysis: ProductWithAnalysis[] = [];

    for (const product of products) {
      const analysis = await this.getProductAnalysis(product.id);
      productsWithAnalysis.push({ ...product, analysis });
    }

    return productsWithAnalysis;
  }
}

export const storage = new MemStorage();

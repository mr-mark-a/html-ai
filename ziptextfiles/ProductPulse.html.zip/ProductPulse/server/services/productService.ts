import { storage } from "../storage";
import { analyzeProduct } from "./openai";
import type { Product, ProductWithAnalysis } from "@shared/schema";

export class ProductService {
  async searchAndAnalyzeProduct(query: string): Promise<ProductWithAnalysis[]> {
    // First search existing products
    const existingProducts = await storage.searchProducts(query);
    
    // Get products with their analyses
    const productsWithAnalysis: ProductWithAnalysis[] = [];
    
    for (const product of existingProducts) {
      let analysis = await storage.getProductAnalysis(product.id);
      
      // If no analysis exists, create one
      if (!analysis) {
        try {
          const aiAnalysis = await analyzeProduct(
            product.name,
            product.description || "",
            product.price
          );
          
          analysis = await storage.createProductAnalysis({
            productId: product.id,
            overallRating: aiAnalysis.overallRating,
            pros: aiAnalysis.pros,
            cons: aiAnalysis.cons,
            summary: aiAnalysis.summary,
            scores: aiAnalysis.scores,
            reviewCount: Math.floor(Math.random() * 2000) + 100 // Simulate review count
          });
        } catch (error) {
          console.error(`Failed to analyze product ${product.id}:`, error);
        }
      }
      
      productsWithAnalysis.push({ ...product, analysis });
    }
    
    return productsWithAnalysis;
  }

  async getProductWithAnalysis(productId: number): Promise<ProductWithAnalysis | null> {
    const product = await storage.getProduct(productId);
    if (!product) return null;

    let analysis = await storage.getProductAnalysis(productId);
    
    // If no analysis exists, create one
    if (!analysis) {
      try {
        const aiAnalysis = await analyzeProduct(
          product.name,
          product.description || "",
          product.price
        );
        
        analysis = await storage.createProductAnalysis({
          productId: product.id,
          overallRating: aiAnalysis.overallRating,
          pros: aiAnalysis.pros,
          cons: aiAnalysis.cons,
          summary: aiAnalysis.summary,
          scores: aiAnalysis.scores,
          reviewCount: Math.floor(Math.random() * 2000) + 100
        });
      } catch (error) {
        console.error(`Failed to analyze product ${productId}:`, error);
      }
    }

    return { ...product, analysis };
  }

  async getFeaturedProducts(): Promise<ProductWithAnalysis[]> {
    const products = await storage.getAllProducts();
    const featured = products.slice(0, 6); // Get first 6 products as featured
    
    const featuredWithAnalysis: ProductWithAnalysis[] = [];
    
    for (const product of featured) {
      const productWithAnalysis = await this.getProductWithAnalysis(product.id);
      if (productWithAnalysis) {
        featuredWithAnalysis.push(productWithAnalysis);
      }
    }
    
    return featuredWithAnalysis;
  }
}

export const productService = new ProductService();

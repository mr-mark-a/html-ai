import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "your-api-key-here" 
});

export interface ProductAnalysisResult {
  overallRating: number;
  pros: string[];
  cons: string[];
  summary: string;
  scores: {
    design: number;
    performance: number;
    camera: number;
    value: number;
  };
}

export async function analyzeProduct(productName: string, productDescription: string, price: number): Promise<ProductAnalysisResult> {
  try {
    const prompt = `
    Analyze the following product and provide a comprehensive review:

    Product: ${productName}
    Description: ${productDescription}
    Price: $${price}

    Please provide a detailed analysis in the following JSON format:
    {
      "overallRating": number between 1-5,
      "pros": array of 5-12 specific positive aspects,
      "cons": array of 2-6 specific negative aspects,
      "summary": "A concise 2-3 sentence summary of the product's strengths and weaknesses",
      "scores": {
        "design": score out of 10 for design and build quality,
        "performance": score out of 10 for performance and functionality,
        "camera": score out of 10 for camera quality (if applicable, otherwise general feature quality),
        "value": score out of 10 for value for money
      }
    }

    Be specific and realistic in your analysis. Consider the price point when evaluating value.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional product reviewer with expertise in technology, consumer goods, and value assessment. Provide honest, detailed reviews based on typical user experiences and market standards."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and sanitize the response
    return {
      overallRating: Math.max(1, Math.min(5, Math.round(result.overallRating * 10) / 10)),
      pros: Array.isArray(result.pros) ? result.pros.slice(0, 12) : [],
      cons: Array.isArray(result.cons) ? result.cons.slice(0, 6) : [],
      summary: result.summary || "Analysis not available",
      scores: {
        design: Math.max(0, Math.min(10, result.scores?.design || 5)),
        performance: Math.max(0, Math.min(10, result.scores?.performance || 5)),
        camera: Math.max(0, Math.min(10, result.scores?.camera || 5)),
        value: Math.max(0, Math.min(10, result.scores?.value || 5))
      }
    };
  } catch (error) {
    console.error("OpenAI analysis failed:", error);
    throw new Error("Failed to analyze product: " + (error as Error).message);
  }
}

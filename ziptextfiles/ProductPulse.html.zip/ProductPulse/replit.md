# ProductScan - AI-Powered Product Analysis Platform

## Overview

ProductScan is a full-stack web application that provides AI-powered product analysis and comparison. Users can search for products, view detailed AI-generated reviews with pros/cons, and compare multiple products side-by-side. The application features a modern, responsive design with real-time product analysis capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state and caching
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Development**: Hot module replacement via Vite middleware integration

### Database & ORM
- **Database**: PostgreSQL (configured via Drizzle)
- **ORM**: Drizzle ORM with Neon Database serverless driver
- **Schema**: Centralized schema definition in shared directory
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Data Layer
- **Products Table**: Stores product information (name, description, price, images, categories)
- **Product Analyses Table**: Stores AI-generated analysis data (ratings, pros/cons, scores)
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development

### AI Integration
- **OpenAI Integration**: GPT-4o for product analysis generation
- **Analysis Features**: Overall ratings, pros/cons lists, category scores (design, performance, camera, value)
- **Fallback Handling**: Graceful error handling for AI service failures

### UI Components
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Component Library**: shadcn/ui components for consistent design
- **Search Interface**: Real-time search with loading states
- **Product Cards**: Rich product displays with ratings and analysis previews
- **Comparison Table**: Side-by-side product comparison functionality

## Data Flow

1. **Product Search**: User searches → API call → Database query → Results with analysis
2. **AI Analysis**: Product without analysis → OpenAI API call → Analysis generation → Database storage
3. **Product Display**: Product request → Database query → Analysis attachment → UI rendering
4. **Comparison**: Multiple products → Analysis validation → Comparison table generation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Database ORM and query builder
- **openai**: AI analysis generation
- **@tanstack/react-query**: Client-side data fetching and caching

### UI Dependencies
- **@radix-ui/***: Accessible component primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for server
- **esbuild**: Production bundling

## Deployment Strategy

### Development
- **Hot Reload**: Vite middleware integrated with Express
- **TypeScript**: Real-time compilation with type checking
- **Environment**: Local development with memory storage fallback

### Production
- **Build Process**: Vite builds client, esbuild bundles server
- **Static Assets**: Client built to dist/public, served by Express
- **Database**: PostgreSQL via environment variable configuration
- **Scaling**: Designed for serverless/container deployment

### Configuration
- **Environment Variables**: DATABASE_URL, OPENAI_API_KEY
- **Path Aliases**: Configured for clean imports (@/, @shared/, @assets/)
- **CORS**: Configured for cross-origin requests in development

The application follows a monorepo structure with clear separation between client, server, and shared code, enabling efficient development and deployment while maintaining code reusability and type safety across the full stack.